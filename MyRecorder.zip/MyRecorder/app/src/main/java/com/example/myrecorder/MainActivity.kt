package com.example.myrecorder

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.myrecorder.databinding.ActivityMainBinding
import com.example.myrecorder.model.MyDatabase
import com.example.myrecorder.model.MyRecord
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.*

class MainActivity : AppCompatActivity() {
    private val binding by lazy { ActivityMainBinding.inflate(layoutInflater) }
    private val sharedPreference by lazy{
        getSharedPreferences("record", Context.MODE_PRIVATE)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        val model = MainViewModel()
        model.getCount().observe(this) { it ->
            binding.textViewCount.text = it.toString()
        }

        val lastFood = sharedPreference.getString("food", null)
        val lastTime = sharedPreference.getString("time", null)
        if(lastFood!=null && lastTime!=null)
            displayRecord(lastFood, lastTime)
        binding.buttonRecord.setOnClickListener {onSave()}
        binding.buttonAddCount.setOnClickListener {
            model.addCount()
        }
        binding.buttonHistory.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
    }

    private fun onSave(){
        with(sharedPreference.edit()){
            val food = binding.editTextFoodName.text.toString()
            if(food.isNotEmpty()) {
                this.putString("food", food)
                val time = LocalDateTime.now().toString()
                this.putString("time", time)
                this.apply()

                CoroutineScope(Dispatchers.IO).launch {
                    val db = MyDatabase.getInstance(this@MainActivity)
                    db?.myDao()?.insert(MyRecord(0, food, time))
                }
            }
        }
    }

        private fun displayRecord(lastFood:String, lastTime:String){
        val lastTime = LocalDateTime.parse(lastTime)
        val now = LocalDateTime.now()
        // 상단 정보 출력
        val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm", Locale.KOREA)
        binding.textViewRecord.text = "${lastTime.format(formatter)} - $lastFood"
        // 하단 경과 시간 출력
        val hours = ChronoUnit.HOURS.between(lastTime, now)
        var minutes = ChronoUnit.MINUTES.between(lastTime, now)
        minutes -= 60*hours
        binding.textViewElapsed.text = String.format(
            Locale.KOREA, "%02d 시간 %02d분 경과"
            , hours, minutes)
    }



}