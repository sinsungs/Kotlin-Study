package com.example.myrecorder
import androidx.lifecycle.*

class MainViewModel: ViewModel() {

    private val count:MutableLiveData<Int> by lazy {
        MutableLiveData<Int>()
    }
    init{
        count.value=0
    }
    fun getCount(): LiveData<Int> { return count }
    // Main Thread 가 아닐 경우 count.postValue
    fun addCount() { count.value = count.value?.plus(1) }
}
