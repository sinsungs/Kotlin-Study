package com.example.listpractice

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.listpractice.util.ChatRoomInfo
import java.util.*

class ChatAdapter():RecyclerView.Adapter<ChatAdapter.ChatViewHolder>() {
    fun interface OnItemClickListener{
        fun onItemClick(v:View, position:Int)
    }
    private var listener:OnItemClickListener? = null

    private var data:MutableList<ChatRoomInfo> = mutableListOf()

    fun setListener(listener: OnItemClickListener){
        this.listener = listener
    }
    fun setData(data:MutableList<ChatRoomInfo>){
        this.data = data
        notifyDataSetChanged()
    }

    fun swapItem(from:Int, to:Int){
        Collections.swap(data, from, to)
        notifyItemMoved(from, to)
    }

    fun removeItem(index:Int){
        data.removeAt(index)
        notifyItemRemoved(index)
    }

    fun getItem(position: Int):ChatRoomInfo{
        return data[position]
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChatViewHolder {
        val view = LayoutInflater
            .from(parent.context)
            .inflate(R.layout.item_chat_list, parent, false)
        return ChatViewHolder(view, listener)
    }

    override fun onBindViewHolder(holder: ChatViewHolder, position: Int) {
        val item = data[position]
        holder.imageView.setImageResource(item.image)
        holder.textViewName.text = item.name
        holder.textViewTime.text = item.time
    }

    override fun getItemCount(): Int {
        return data.size
    }

    class ChatViewHolder(view: View, listener: OnItemClickListener?):RecyclerView.ViewHolder(view){
        val textViewName:TextView = view.findViewById(R.id.textViewName)
        val textViewTime:TextView = view.findViewById(R.id.textViewTime)
        val imageView: ImageView = view.findViewById(R.id.imageView)
        init{
            view.setOnClickListener {
                Log.d("List","${this.layoutPosition}th item clicked");
                listener?.onItemClick(view, this.layoutPosition)
            }
        }
    }

}